The task/file runs exactly as requested. The notable differences is drastic. 

Both c programs create 1000 threads/processes instead of the original 10.
My code is in the ‘COPY’ c files for both. I kept the original c files for reference back in case I ever needed it. 

The thread time in Microseconds averaged about 27-28.
While the process time in Microseconds averaged about 330-345.
A drastic time difference. 