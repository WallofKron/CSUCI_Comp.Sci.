tune('Elegy','Frail Words Collapse','As I Lay Dying','Metal','mp3',256).
tune('Confined','Shadows Are Security','As I Lay Dying','Metal','mp3',256).
tune('Ghosts','Found In Far Away Places','August Burns Red','Metal','mp3',256).
tune('Marianas Trench','Constellations','August Burns Red','Metal','mp3',256).
tune('Horizon','Random Access Memories','Daft Punk','Electronic','mp3',256).
tune('One More Time/Aerodynamic','Alive','Daft Punk','Electronic','mp3',256).
tune('Harder, Better, Faster, Stronger','Discovery','Daft Punk','Electronic','mp3',256).
tune('Tranquil','Undoing Ruin','Darkest Hour','Thrash','mp3',256).
tune('These Fevered Times','Undoing Ruin','Darkest Hour','Thrash','mp3',256).
tune('Low','Undoing Ruin','Darkest Hour','Thrash','mp3',256).
tune('Full Imperial Collapse','Deliver Us','Darkest Hour','Thrash','mp3',256).
tune('Blazing Star','Doomstar Requiem','Dethklok','Opera','mp3',320).
tune('The Galaxy','Dethalbum 3','Dethklok','Metal','mp3',320).
tune('Rejoin','Dethalbum 3','Dethklok','Metal','mp3',320).
tune('This Is Who We Are','An Ocean Between Us','As I Lay Dying','Metal','mp3',320).
tune('Deliver Us','Deliver Us','Darkest Hour','Thrash','mp3',320).
tune('Comet Song','Dethalbum 2','Dethklok','Metal','mp3',320).
tune('Thunderhorse','The Dethalbum','Dethklok','Metal','mp3',320).
tune('All I Want','What Seperates Me From You','A Day To Remember','Rock','WAV',192).
tune('The Downfall Of Us All','Homesick','A Day To Remember','Rock','WAV',192).
tune('My Life For Hire','Homesick','A Day To Remember','Rock','WAV',192).
tune('If It Means Alot To You','Homesick','A Day To Remember','Rock','WAV',192).
tune('Sticks & Bricks','What Seperates Me From You','A Day To Remember','Rock','WAV',192).
tune('Wheel In the Sky','Infinity','Journey','Rock','WAV',192).
tune('Dont Stop Believin','Escape','Journey','Rock','WAV',192).
tune('Faithfully','Frontiers','Journey','Rock','WAV',192).
tune('Stairway To Heaven','Led Zeppelin IV','Led Zeppelin','Classic Rock','m4a',192).
tune('Black Dog','Led Zeppelin IV','Led Zeppelin','Classic Rock','m4a',192).
tune('When The Levee Breaks','Led Zeppelin III','Led Zeppelin','Classic Rock','m4a',192).
tune('Ramble On','Led Zeppelin II','Led Zeppelin','Classic Rock','m4a',440).
tune('Good Times','Led Zeppelin','Led Zeppelin','Classic Rock','m4a',440).
tune('My Name Is Mud','Pork Soda','Primus','Funk Rock','m4a',440).
tune('Too Many Puppies','Frizzle Fry','Primus','Funk Rock','m4a',800).
tune('Jerry Was A Racecar Driver','Sailing The Seas Of Cheese','Primus','Funk Rock','m4a',800).
tune('The Mason','Wovenwar','Wovenwar','Hard Rock','m4a',800).
tune('Death To Rights','Wovenwar','Wovenwar','Hard Rock','m4a',440).
tune('Matter Of Time','Wovenwar','Wovenwar','Hard Rock','m4a',440).
tune('Prophets','Wovenwar','Wovenwar','Hard Rock','m4a',440).
tune('Identity','Wovenwar','Wovenwar','Hard Rock','m4a',440).
tune('Profane','Wovenwar','Wovenwar','Hard Rock','m4a',440).
tune('Writings On The Wall','IRE','Parkway Drive','Metal','m4a',440).
tune('A Deathless Song','IRE','Parkway Drive','Metal','m4a',440).
tune('Bottom Feeder','IRE','Parkway Drive','Metal','AAC',440).
tune('Swing','Atlas','Parkway Drive','Metal','AAC',440).
tune('Blue And The Grey','Atlas','Parkway Drive','Metal','AAC',440).
tune('Deliver Me','Deep Blue','Parkway Drive','Metal','AAC',440).
tune('Karma','Deep Blue','Parkway Drive','Metal','AAC',440).
tune('Carrion','Horizons','Parkway Drive','Metal','AAC',800).
tune('Idols And Anchors','Horizons','Parkway Drive','Metal','AAC',800).
tune('Ghosts And Stuff','For Lack Of A Better Name','DeadMau5','Electronic','AAC',800).
tune('Raise Your Weapon','4X4=12','DeadMau5','Electronic','AAC',800).
tune('Sofi Needs A Ladder','4X4=12','DeadMau5','Electronic','AAC',800).
tune('Faxing Berlin','Random Album Title','DeadMau5','Electronic','AAC',800).
tune('Faxing Berlin','ACDB','Stormfront','Electronic','AAC',440).
tune('Faxing Berlin','Random Album Title','DeadMau5','Electronic','mp3',320).
tune('Faxing Berlin','ACBD','Stormfront','Electronic','mp3',425).