#include <stdio.h>

int main(void)
{
    printf("Hello World. \n \t and you ! \n ");
		/* print out a message */
    return 0;
}

