//
//  l6t4.c
//  Created by Robert Florence on 3/3/16
//
#include "parser.h"


int main(){
    
    AST_NODE *fullProgram;
        
        fullProgram = program();
     //   print_program(fullProgram);
    
    return 0;
}