/*
 Robert Florence
 Project - task1/2
 Prof. Bieszczad
 CSUCI
 3-18-16
 
 */



#include "l8t3.h"

int main(void)
{
    yyparse();
    return 0;
}

void yyerror(char *s)
{
    fprintf(stderr, "%s\n", s);
}

// find out which function it is
int resolveFunc(char *func)
{
    char *funcs[] = { "neg", "abs", "exp", "sqrt", "add", "sub", "mult", "div", "remainder", "log", "pow", "max", "min", "cbrt", "exp2", "hypot"};
    
    int i = 0;
    while (funcs[i][0] !='\0')
    {
        if (!strcmp(funcs[i], func))
            return i;
        
        i++;
    }
    yyerror("invalid function"); // paranoic -- should never happen
    return -1;
}

// create a node for a number
AST_NODE *number(double value)
{
    AST_NODE *p;
    size_t nodeSize;
    
    // allocate space for the fixed size and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(NUMBER_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");
    
    p->type = NUM_TYPE;
    p->data.number.value = value;
    
    return p;
}

// create a node for a function
AST_NODE *function(char *funcName, AST_NODE *op1, AST_NODE *op2)
{
    AST_NODE *p;
    size_t nodeSize;
    
    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(FUNCTION_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL){
        yyerror("out of memory");
    }
    
    p->type = FUNC_TYPE;
    p->data.function.name = funcName;
    p->data.function.op1 = op1;
    p->data.function.op2 = op2;
    
    return p;
}

// free a node
void freeNode(AST_NODE *p)
{
    if (!p){
        return;
    }
    
    if (p->type == FUNC_TYPE)
    {
        free(p->data.function.name);
        freeNode(p->data.function.op1);
        freeNode(p->data.function.op2);
    }
    
    free (p);
}

void translate(AST_NODE *p)
{
    if (!p){
        return;
    }
    
    int functnum = 0;
    functnum = resolveFunc(p->data.function.name);
    
    char *func = p->data.function.name;
    
    AST_NODE *op1 = p->data.function.op1;
    AST_NODE *op2 = 0;
    
    if((functnum >= 4 && functnum <=12) || functnum == 15){
        op2 = p->data.function.op2;
    }
    
    switch(functnum){
            
        case 0:
            if (op1->type == 0) {
                
                printf("%s(%f)", func, op1->data.number.value);
                
            }else{
                printf("%s(",func);
                translate(op1);
                printf(")");

            }
            break;
            
        case 1:
            if (op1->type == 0) {
                
                printf(" %s(%f) ", func, op1->data.number.value);
                
            }else{
                printf("%s(",func);
                translate(op1);
                printf(")");
                
            }
            break;
            
        case 2:
            if (op1->type == 0) {
                
                printf("%s(%f)", func, op1->data.number.value);
                
            }else{
                printf(" %s(",func);
                translate(op1);
                printf(")");
                
            }
            break;
        
        case 3:
            if (op1->type == 0) {
                
                printf("%s(%f)", func, op1->data.number.value);
                
            }else{
                printf("%s(",func);
                translate(op1);
                printf(")");
                
            }
            break;
            
        case 4:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("(%f + %f)", op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("(");
                    translate(op1);
                    printf(" + ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }

                }
                else{
                    printf("(%f + ", op1->data.number.value);
                    translate(op2);
                    printf(")");

                }
            }
            break;
            
        case 5:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("(%f - %f)", op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("(");
                    translate(op1);
                    printf(" - ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }
                else{
                    printf("(%f - ", op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 6:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("(%f * %f)", op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("(");
                    translate(op1);
                    printf(" * ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }
                else{
                    printf("(%f * ", op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 7:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("(%f / %f)", op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("(");
                    translate(op1);
                    printf(" / ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }
                else{
                    printf("(%f / ", op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 8:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 9:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 10:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 11:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 12:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        case 13:
            if (op1->type == 0) {
                
                printf("%s(%f)", func, op1->data.number.value);
                
            }else{
                printf("%s(",func);
                translate(op1);
                printf(")");
                
            }
            break;
            
        case 14:
            if (op1->type == 0) {
                
                printf("%s(%f)", func, op1->data.number.value);
                
            }else{
                printf("%s(",func);
                translate(op1);
                printf(")");
                
            }
            break;
            
        case 15:
            if (op1->type == 0 && op2->type == 0) {
                
                printf("%s(%f, %f)", func, op1->data.number.value, op2->data.number.value);
                
            }else{
                if (op1->type == 1) {
                    printf("%s(",func);
                    translate(op1);
                    printf(", ");
                    
                    if (op2->type==1) {
                        translate(op2);
                        printf(")");
                    } else {
                        printf("%f)", op2->data.number.value);
                    }
                    
                }else{
                    printf("%s(%f, ", func, op1->data.number.value);
                    translate(op2);
                    printf(")");
                    
                }
            }
            break;
            
        default:
            printf("ERROR");
            break;
    }
    
    
}